public class BooleanTest {
	public static void main(String[] args) {
		boolean iscat = true;
		if (iscat) {
			System.out.println("����һֻè�䣡");
		} else {
			System.out.println("�ⲻ��һֻè�䡣");
		}
	}
}